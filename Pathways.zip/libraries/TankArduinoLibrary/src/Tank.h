#ifndef Tank_H_
#define Tank_H_

#include "TankClient.h"

TankClient Tank;

#endif